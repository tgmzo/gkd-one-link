import { defineGkdApp } from '@gkd-kit/define';

export default defineGkdApp({
  id: 'tv.danmaku.bili',
  name: '哔哩哔哩',
  groups: [
    {
      key: 2,
      name: '分段广告-动态推荐广告卡片',
      desc: '关闭动态页面的广告卡片',
      enable: false,
      fastQuery: true,
      matchDelay: 5000,
      activityIds: 'tv.danmaku.bili.MainActivityV2',
      rules: [
        {
          key: 1,
          matches: '[vid="ad_goods_mark_big"]',
          snapshotUrls: 'https://i.gkd.li/import/12700222',
        },
        {
          preKeys: [1],
          matches: '[text="不感兴趣"][id^="tv.danmaku.bili:id/reason"]',
          snapshotUrls: 'https://i.gkd.li/import/12700243',
        },
      ],
    },
    {
      key: 4,
      name: '分段广告-视频及搜索卡片广告',
      desc: '关闭视频流和搜索结果中的广告卡片，包括视频底部、评论区中间、详情页下方等位置',
      enable: false,
      rules: [
        {
          key: 0,
          name: '点击广告卡片右侧菜单图标',
          activityIds: [
            'tv.danmaku.bili.MainActivityV2',
            'com.bilibili.video.videodetail.VideoDetailsActivity',
            'com.bilibili.ship.theseus.all.UnitedBizDetailsActivity',
            'com.bilibili.ship.theseus.detail.UnitedBizDetailsActivity',
          ],
          anyMatches: [
            '[height > prev.bottom.plus(200)] >n [(((desc*="广告"||desc*="来自淘宝")&&desc*="查看")||desc$=",,轻点两下查看详情"||(desc^="【有奖调研】"&&desc.length=22))||(id*="/ad_")][visibleToUser=true] >(2,3,4) @ImageView[visibleToUser=true] < [vid^="more" || id^="tv.danmaku.bili.adbiz:id/more"][visibleToUser=true]',
            '[id$="ad_tint_frame" || id$="root_container" || id$="constraintLayout"][visibleToUser=true] >(1,2,3) [vid="more" || id="tv.danmaku.bili.adbiz:id/more"]',
            '[text="课堂" || text="纪录片" || text="游戏" || vid="bottom_container" || vid="live_lottie_layout"][index=2] +n [vid="more"][visibleToUser=true]',
          ],
          snapshotUrls: [
            'https://i.gkd.li/import/12642260', // n = 2
            'https://i.gkd.li/import/12705266', // n = 3
            'https://i.gkd.li/import/12776568', // id="tv.danmaku.bili:id/more_layout"
            'https://i.gkd.li/import/12707070', // 由于 activityId 切换延迟导致规则仍然运行, 使用 FrameLayout 避免误触
            'https://i.gkd.li/i/14083540',
            'https://i.gkd.li/i/14059876', // n = 4
            'https://i.gkd.li/i/14588315',
            'https://i.gkd.li/i/14729855',
            'https://i.gkd.li/i/17690786',
            'https://i.gkd.li/i/17690800',
            'https://i.gkd.li/i/17675629',
            'https://i.gkd.li/i/18274379',
            'https://i.gkd.li/i/19777632',
            'https://i.gkd.li/i/19919163',
            'https://i.gkd.li/i/19919168',
            'https://i.gkd.li/i/20739380',
            'https://i.gkd.li/i/20744764',
            'https://i.gkd.li/i/20794380',
            'https://i.gkd.li/i/21552836',
            'https://i.gkd.li/i/21705345',
            'https://i.gkd.li/i/21947622',
            'https://i.gkd.li/i/18306851',
            'https://i.gkd.li/i/19537979',
            'https://i.gkd.li/i/23012670',
            'https://i.gkd.li/i/23123800',
            'https://i.gkd.li/i/23687196',
            'https://i.gkd.li/i/27153803',
            'https://i.gkd.li/i/27686976',
            'https://i.gkd.li/i/23934632', // 课堂
            'https://i.gkd.li/i/23933866', // 纪录片
            'https://i.gkd.li/i/24015674', // 游戏
            'https://i.gkd.li/i/23933925', // vid="bottom_container"
            'https://i.gkd.li/i/17675894', // 直播 vid="live_lottie_layout"
            'https://i.gkd.li/i/18306858', // 直播
            'https://i.gkd.li/i/28908101', // [vid="more_layout"] 视频暂停播放时出现的广告
          ],
          excludeSnapshotUrls: ['https://i.gkd.li/i/23833031'], // 会出现按钮在底部导航栏后且visibleToUser=true的情况，需要使用 [height > prev.bottom.plus(200)] 排除，原理是根元素的高度必须大于右侧元素（视频卡片元素）bottom+200
        },
        {
          preKeys: [0],
          key: 49,
          fastQuery: true,
          name: '点击[我不想看]',
          activityIds: [
            'tv.danmaku.bili.MainActivityV2',
            'com.bilibili.video.videodetail.VideoDetailsActivity',
            'com.bilibili.ship.theseus.all.UnitedBizDetailsActivity',
            'com.bilibili.ship.theseus.detail.UnitedBizDetailsActivity',
          ],
          matches: '[vid="recycler"] >n [text="我不想看"]',
          snapshotUrls: ['https://i.gkd.li/i/17786751'],
        },
        {
          preKeys: [0, 49],
          key: 50,
          fastQuery: true,
          name: '点击[不感兴趣]',
          activityIds: [
            'tv.danmaku.bili.MainActivityV2',
            'com.bilibili.video.videodetail.VideoDetailsActivity',
            'com.bilibili.ship.theseus.all.UnitedBizDetailsActivity',
            'com.bilibili.ship.theseus.detail.UnitedBizDetailsActivity',
          ],
          matches:
            '@[clickable=true] > [text="这个内容" || text="不感兴趣" || text="相似内容过多" || text="up主不感兴趣" || text="此类内容过多" || text="对该up的直播不感兴趣"|| text*="不想看" || text$="质量差" || text="减少直播推荐" || text="和当前视频无关"]',
          snapshotUrls: [
            'https://i.gkd.li/import/13495649',
            'https://i.gkd.li/i/13742257',
            'https://i.gkd.li/i/13256605',
            'https://i.gkd.li/i/14155801',
            'https://i.gkd.li/i/13742257',
            'https://i.gkd.li/i/13945597',
            'https://i.gkd.li/i/14155272',
            'https://i.gkd.li/i/14059882',
            'https://i.gkd.li/i/13625309',
            'https://i.gkd.li/i/12642261',
            'https://i.gkd.li/i/17676025',
            'https://i.gkd.li/i/17676149',
            'https://i.gkd.li/i/17677147',
            'https://i.gkd.li/i/17786753',
            'https://i.gkd.li/i/18266291',
            'https://i.gkd.li/i/18274380',
            'https://i.gkd.li/i/18292926',
            'https://i.gkd.li/i/18296940',
            'https://i.gkd.li/i/18306839',
            'https://i.gkd.li/i/19777674',
            'https://i.gkd.li/i/19919165',
            'https://i.gkd.li/i/19919169',
            'https://i.gkd.li/i/20710223',
            'https://i.gkd.li/i/20718890',
            'https://i.gkd.li/i/20720187',
            'https://i.gkd.li/i/20739391',
            'https://i.gkd.li/i/23687208',
            'https://i.gkd.li/i/24836772',
            'https://i.gkd.li/i/24015691', // 我不想看
            'https://i.gkd.li/i/28659010', // 不想看该内容、广告质量差
            'https://i.gkd.li/i/30885647', // 减少直播推荐、和当前视频无关
          ],
        },
        {
          preKeys: [50],
          key: 51,
          name: '点击关闭',
          fastQuery: true,
          activityIds: [
            'tv.danmaku.bili.MainActivityV2',
            'com.bilibili.video.videodetail.VideoDetailsActivity',
            'com.bilibili.ship.theseus.all.UnitedBizDetailsActivity',
            'com.bilibili.ship.theseus.detail.UnitedBizDetailsActivity',
          ],
          anyMatches: [
            '[vid="close_dislike"][visibleToUser=true]',
            '@[text="关闭"][clickable=true] -n * <<(2,4) [name$="ComposeView" || name$="FrameLayout"] <n [vid="recycler"]',
          ],
          snapshotUrls: [
            'https://i.gkd.li/i/17675894',
            'https://i.gkd.li/i/18587456',
            'https://i.gkd.li/i/25739074',
          ],
        },
        {
          key: 52,
          name: '搜索结果-点击右下角[菜单]',
          fastQuery: true,
          activityIds: 'com.bilibili.search2.main.BiliMainSearchActivity',
          matches: '[vid="ad_tint_frame"] > [vid="more"][clickable=true]',
          snapshotUrls: [
            'https://i.gkd.li/i/17269053',
            'https://i.gkd.li/i/17964354',
            'https://i.gkd.li/i/28495212',
          ],
        },
        {
          key: 53,
          preKeys: [52],
          name: '搜索结果-点击[不感兴趣]',
          fastQuery: true,
          activityIds: 'com.bilibili.search2.main.BiliMainSearchActivity',
          matches:
            '@[clickable=true] > [text$="不感兴趣" || text*="不想看" || text$="质量差"]',
          snapshotUrls: [
            'https://i.gkd.li/i/17269055',
            'https://i.gkd.li/i/17964356',
            'https://i.gkd.li/i/22657666', // 直播
          ],
        },
      ],
    },
    {
      key: 5,
      name: '局部广告-会员购',
      desc: '底部横幅Ad',
      rules: [
        {
          fastQuery: true,
          activityIds: '.MainActivityV2',
          matches: '[vid="mall_home_newuser_coupon_close"][clickable=true]',
          snapshotUrls: 'https://i.gkd.li/i/26240948',
        },
      ],
    },
    {
      key: 6,
      name: '局部广告-首页浮标广告',
      rules: [
        {
          fastQuery: true,
          activityIds: '.MainActivityV2',
          matches: '[vid="animation_close"][clickable=true]',
          snapshotUrls: 'https://i.gkd.li/i/25357810',
        },
      ],
    },
    {
      key: 7,
      name: '局部广告-视频页广告',
      desc: '关闭视频页面的会员推广弹窗和免流星卡广告',
      fastQuery: true,
      rules: [
        {
          key: 1,
          matchTime: 10000,
          actionMaximum: 1,
          activityIds: [
            'com.bilibili.ship.theseus.detail.UnitedBizDetailsActivity',
            'com.bilibili.video.videodetail.VideoDetailsActivity',
          ],
          matches: '[vid="toast_x"]',
          snapshotUrls: [
            'https://i.gkd.li/i/12892611',
            'https://i.gkd.li/i/13308344',
            'https://i.gkd.li/i/13538048',
          ],
        },
        {
          key: 2,
          activityIds:
            'com.bilibili.ship.theseus.detail.UnitedBizDetailsActivity',
          matches:
            '@[vid="close"][visibleToUser=true] - [text$="免费领B站大会员"]',
          snapshotUrls: 'https://i.gkd.li/i/18165189',
        },
        {
          key: 3,
          activityIds:
            'com.bilibili.ship.theseus.detail.UnitedBizDetailsActivity',
          matches:
            '[desc="close"] < @[clickable=true] <3 View <2 [childCount=4] < View <2 View < ComposeView < FrameLayout < [vid="fl_tab_pager_container"]',
          snapshotUrls: 'https://i.gkd.li/i/31067294',
        },
      ],
    },
    {
      key: 8,
      name: '局部广告-直播间悬浮窗广告',
      desc: '关闭直播间的悬浮窗广告',
      fastQuery: true,
      activityIds: 'com.bilibili.bililive.room.ui.roomv3.LiveRoomActivityV3',
      rules: [
        {
          key: 0,
          matches:
            '[id="tv.danmaku.bili:id/shopping_close" || vid="live_game_card_close" || vid="match_close" || vid="iv_pop_rank_guide_card_close"][visibleToUser=true]',
          snapshotUrls: [
            'https://i.gkd.li/i/13200549',
            'https://i.gkd.li/i/22990081',
            'https://i.gkd.li/i/23098023',
            'https://i.gkd.li/i/25238734',
          ],
        },
        {
          key: 1,
          forcedTime: 120000, // 主动查询2分钟
          matches:
            '@[vid="close" || vid="iv_close"] - [vid="up_avatar" || vid="gift_icon" || vid="follow_container"][visibleToUser=true]',
          snapshotUrls: [
            'https://i.gkd.li/i/14782965',
            'https://i.gkd.li/i/32246446',
            'https://i.gkd.li/i/18046573',
            'https://i.gkd.li/i/22990105',
          ],
        },
        {
          key: 2,
          matchTime: 10000,
          actionMaximum: 1, //防止循环展开关闭
          matches:
            'View[visibleToUser=true] <<2 @[clickable=true] < [vid="pager"]',
          snapshotUrls: [
            'https://i.gkd.li/i/24985920',
            'https://i.gkd.li/i/25240029',
          ],
          excludeSnapshotUrls: ['https://i.gkd.li/i/25369451'],
        },
      ],
    },
    {
      key: 10,
      name: '功能类-自动关闭故事模式',
      desc: '退出视频播放时的竖屏故事模式',
      enable: false,
      matchTime: 10000,
      actionMaximum: 1,
      rules: [
        {
          fastQuery: true,
          activityIds: [
            'com.bilibili.video.story.StoryVideoActivity',
            'com.bilibili.video.story.StoryTransparentActivity',
          ],
          matches: '[vid="story_ctrl_router"][visibleToUser=true]',
          snapshotUrls: [
            'https://i.gkd.li/i/18164075',
            'https://i.gkd.li/i/23325994',
          ],
        },
      ],
    },
    {
      key: 11,
      name: '功能类-自动点击评论区的[展开更多评论]',
      desc: '自动点击评论区的[展开更多评论]',
      enable: false,
      rules: [
        {
          fastQuery: true,
          activityIds: [
            'com.bilibili.video.story.StoryVideoActivity',
            'com.bilibili.video.story.StoryTransparentActivity',
            'com.bilibili.ship.theseus.detail.UnitedBizDetailsActivity',
            'com.bilibili.ship.theseus.playlist.UnitedPlaylistActivity',
          ],
          matches: '@LinearLayout[clickable=true] > [text="展开更多评论"]',
          snapshotUrls: [
            'https://i.gkd.li/i/22572375',
            'https://i.gkd.li/i/23325508',
            'https://i.gkd.li/i/22573433',
            'https://i.gkd.li/i/23786106',
          ],
        },
      ],
    },
    {
      key: 12,
      name: '全屏广告-完善信息弹窗',
      desc: '按[返回键]',
      enable: false,
      rules: [
        {
          fastQuery: true,
          action: 'back',
          activityIds: '.MainActivityV2',
          matches:
            '[vid="design_bottom_sheet"] >2 [vid="title"][text="完善信息，获取精准推荐"]',
          snapshotUrls: 'https://i.gkd.li/i/31165755',
        },
      ],
    },
    {
      key: 18,
      name: '功能类-自动领取会员经验',
      desc: '在会员中心页面自动领取会员经验',
      enable: false,
      rules: [
        {
          fastQuery: true,
          activityIds: 'com.bilibili.vip.web.VipWebActivity',
          matches:
            '@TextView[index=parent.childCount.minus(1)][text="领取"] -n [text="领经验"] < View <(2,3) View <3 View < [id="app"][getChild(childCount.minus(1)).text$="隐私政策"] <<(5,6) [vid="webview"]',
          snapshotUrls: [
            'https://i.gkd.li/i/22886723', // 领取前
            'https://i.gkd.li/i/22886739', // 领取后
          ],
          excludeSnapshotUrls: 'https://i.gkd.li/i/23385023', // [getChild(childCount.minus(1)).text$="隐私政策"] 排除弹窗
        },
      ],
    },
    {
      key: 19,
      name: '功能类-自动点击查看原图',
      desc: '浏览图片时自动切换至原图模式',
      enable: false,
      rules: [
        {
          fastQuery: true,
          activityIds: [
            'com.bilibili.video.story.StoryVideoActivity', // 视频：竖屏模式1
            'com.bilibili.video.story.StoryTransparentActivity', // 视频：竖屏模式2
            'com.bilibili.ship.theseus.detail.UnitedBizDetailsActivity', // 视频：详情页模式
            'com.bilibili.ship.theseus.playlist.UnitedPlaylistActivity', // 视频：播放列表（稍后再看/收藏夹）
            'com.bilibili.bplus.followinglist.page.browser.ui.LightBrowserActivityV2', // 动态：图片
            'com.bilibili.lib.ui.ComposeActivity', // 动态：评论图片
            'com.bilibili.column.ui.detail.image.ColumnImageViewerActivity', // 专栏图片
          ],
          matches: '[text^="查看原图"][visibleToUser=true]',
          snapshotUrls: [
            'https://i.gkd.li/i/23325552', // 视频：竖屏模式1
            'https://i.gkd.li/i/23304237', // 视频：竖屏模式2
            'https://i.gkd.li/i/23304245', // 视频：详情页模式
            'https://i.gkd.li/i/23786065', // 视频：播放列表（稍后再看/收藏夹）
            'https://i.gkd.li/i/23305280', // 动态：帖内图片
            'https://i.gkd.li/i/23305281', // 动态：评论图片
            'https://i.gkd.li/i/23305275', // 专栏图片
          ],
        },
      ],
    },
    {
      key: 20,
      name: '功能类-登录授权',
      desc: '点击确认授权按钮',
      enable: false,
      rules: [
        {
          key: 0,
          activityIds: '.ui.webview.MWebActivity',
          fastQuery: true,
          matches: [
            '[text="哔哩哔哩扫码登录"]',
            '[text="确认"][visibleToUser=true]',
          ],
          snapshotUrls: 'https://i.gkd.li/i/24989484',
        },
      ],
    },
    {
      key: 21,
      name: '局部广告-视频页-即将展示Ad',
      desc: '视频途中[x秒后展示广告] -> 取消',
      rules: [
        {
          fastQuery: true,
          activityIds:
            'com.bilibili.ship.theseus.detail.UnitedBizDetailsActivity',
          matches:
            '@[text="取消"][clickable=true][visibleToUser=true] - [text="后将展示广告"] <2 View[childCount=3] <<2 ComposeView <<3 FrameLayout[childCount=1] <n * < [vid="video_container"]',
          snapshotUrls: 'https://i.gkd.li/i/29379312',
        },
      ],
    },
  ],
});
